﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace frmMain
{
    public partial class otrisovka : Form
    {
        Graphics g;
        Random rnd = new Random();

        public otrisovka()
        {
            InitializeComponent();
        }

        private void otrisovka_Load(object sender, EventArgs e)
        {


        }

        private void Selector_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = int.Parse(Selector.SelectedIndex.ToString());
            MessageBox.Show(Selector.SelectedIndex.ToString());
        }

        private void DrawField_Click(object sender, EventArgs e)
        {
           
            g = this.DrawField.CreateGraphics();
            int x = rnd.Next(0, this.ClientSize.Width);
            int y = rnd.Next(0, this.ClientSize.Height);

            switch (Convert.ToInt32(Selector.SelectedIndex))
            {
                case 0: // Параллелограмм
                    Point[] parallelogramPoints = { new Point(x, y), new Point(x + 30, y), new Point(x + 50, y + 30), new Point(x + 20, y + 30) };
                    g.DrawPolygon(Pens.Black, parallelogramPoints);
                    break;
                case 1: // Трапеция
                    Point[] trapezoidPoints = { new Point(x + 10, y), new Point(x + 40, y), new Point(x + 30, y + 30), new Point(x + 20, y + 30) };
                    g.DrawPolygon(Pens.Black, trapezoidPoints);
                    break;
                case 2: // Закрашенный круг
                    g.FillEllipse(Brushes.Black, x, y, 30, 30);
                    break;
                case 3: // Квадрат
                    g.DrawRectangle(Pens.Black, x, y, 30, 30);
                    break;
                case 4: // Эллипс
                    g.DrawEllipse(Pens.Black, x, y, 50, 30);
                    break;
                case 5: // Прямоугольник
                    g.DrawRectangle(Pens.Black, x, y, 50, 30);
                    break;
                case 6: // Прямоугольный треугольник
                    Point[] rightTrianglePoints = { new Point(x, y), new Point(x, y + 30), new Point(x + 30, y + 30) };
                    g.DrawPolygon(Pens.Black, rightTrianglePoints);
                    break;
                case 7: // Равносторонний треугольник
                    Point[] equilateralTrianglePoints = { new Point(x, y + 30), new Point(x + 30, y + 30), new Point(x + 15, y) };
                    g.DrawPolygon(Pens.Black, equilateralTrianglePoints);
                    break;
                case 8: // Окружность
                    g.DrawEllipse(Pens.Black, x, y, 30, 30);
                    break;
                case 9: // Ромб
                    Point[] points = { new Point(x, y + 15), new Point(x + 25, y), new Point(x + 50, y + 15), new Point(x + 25, y + 30) };
                    g.DrawPolygon(Pens.Black, points);
                    break;
                case 10: // Равнобедренный треугольник
                    Point[] isoscelesTrianglePoints = { new Point(x, y), new Point(x + 30, y), new Point(x + 15, y + 30) };
                    g.DrawPolygon(Pens.Black, isoscelesTrianglePoints);
                    break;
                case 11: // Надпись "Текст" 
                    Rectangle textRect = new Rectangle(x, y, 100, 50);
                    StringFormat sf = new StringFormat
                    {
                        LineAlignment = StringAlignment.Center,
                        Alignment = StringAlignment.Center
                    };
                    g.DrawString("Текст", this.Font, Brushes.Black, textRect, sf);
                    break;
               
            }

        }

    }
}
