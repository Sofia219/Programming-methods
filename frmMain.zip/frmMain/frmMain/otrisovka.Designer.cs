﻿
namespace frmMain
{
    partial class otrisovka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Selector = new System.Windows.Forms.ComboBox();
            this.DrawField = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DrawField)).BeginInit();
            this.SuspendLayout();
            // 
            // Selector
            // 
            this.Selector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Selector.FormattingEnabled = true;
            this.Selector.Items.AddRange(new object[] {
            "Параллелограмм",
            "Трапеция",
            "Круг",
            "Квадрат",
            "Эллипс",
            "Прямоугольник",
            "Прямоугольный треугольник",
            "Равносторонний треугольник",
            "Окружность",
            "Ромб",
            "Равнобедренный треугольник",
            "Надпись \"Текст\""});
            this.Selector.Location = new System.Drawing.Point(45, 26);
            this.Selector.Name = "Selector";
            this.Selector.Size = new System.Drawing.Size(121, 24);
            this.Selector.TabIndex = 0;
            this.Selector.SelectedIndexChanged += new System.EventHandler(this.Selector_SelectedIndexChanged);
            // 
            // DrawField
            // 
            this.DrawField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DrawField.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DrawField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DrawField.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DrawField.Location = new System.Drawing.Point(115, 68);
            this.DrawField.Name = "DrawField";
            this.DrawField.Size = new System.Drawing.Size(1346, 597);
            this.DrawField.TabIndex = 1;
            this.DrawField.TabStop = false;
            this.DrawField.Click += new System.EventHandler(this.DrawField_Click);
            // 
            // otrisovka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1816, 716);
            this.Controls.Add(this.Selector);
            this.Controls.Add(this.DrawField);
            this.Name = "otrisovka";
            this.Text = "Область рисования";
            this.Load += new System.EventHandler(this.otrisovka_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DrawField)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox Selector;
        private System.Windows.Forms.PictureBox DrawField;
    }
}