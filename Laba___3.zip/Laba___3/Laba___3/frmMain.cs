﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Laba___3
{
    public partial class frmMain : Form
    {
        private System.Windows.Forms.Button btnStart;


        public frmMain()
        {
            InitializeComponent();

        }
        bool check = false;
      


        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Text = "Задание №3 выполнили: Поваляева А.В., Топталова С.Д.; Номер варианта: 2; Дата выполнения: 20/05/2024";
            this.ClientSize = new Size(800, 500);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.ControlBox = false;
            this.BackColor = Color.PeachPuff;

            this.btnStart = new System.Windows.Forms.Button();
            btnStart.Size = new System.Drawing.Size(250, 100);
            btnStart.Location = new Point(280, 180);
            btnStart.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnStart.Text = "Старт";
            btnStart.BackColor = Color.AliceBlue;
            btnStart.Click += new EventHandler(btnStart_Click);
            btnStart.AutoSize = false;
            this.Controls.Add(btnStart);

            System.Windows.Forms.Button btnClose = new System.Windows.Forms.Button();
            btnClose.Size = new System.Drawing.Size(30, 30);
            btnClose.Location = new Point(755, 455);
            btnClose.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnClose.Text = "X";
            btnClose.BackColor = Color.AliceBlue;
            btnClose.Click += new EventHandler(btnClose_Click);
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            this.Controls.Add(btnClose);

            System.Windows.Forms.Button btnWrap = new System.Windows.Forms.Button();
            btnWrap.Size = new System.Drawing.Size(30, 30);
            btnWrap.Location = new Point(725, 455);
            btnWrap.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnWrap.Text = "-";
            btnWrap.BackColor = Color.AliceBlue;
            btnWrap.Click += new EventHandler(btnWrap_Click);
            btnWrap.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            this.Controls.Add(btnWrap);

            System.Windows.Forms.Button btnTurn = new System.Windows.Forms.Button();
            btnTurn.Size = new System.Drawing.Size(30, 30);
            btnTurn.Location = new Point(695, 455);
            btnTurn.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnTurn.Text = "";
            btnTurn.BackColor = Color.AliceBlue;
            btnTurn.Click += new EventHandler(btnTurn_Click);
            btnTurn.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            this.Controls.Add(btnTurn);

            System.Windows.Forms.Button btnSpravka = new System.Windows.Forms.Button();
            btnSpravka.Size = new System.Drawing.Size(300, 30);
            btnSpravka.Location = new Point(15, 455);
            btnSpravka.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnSpravka.Text = "Справочная информация";
            btnSpravka.BackColor = Color.AliceBlue;
            btnSpravka.Click += new EventHandler(btnSpravka_Click);
            btnSpravka.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            this.Controls.Add(btnSpravka);
        }

        private void btnTurn_Click(object sender, EventArgs e)
        {
            if (check == false)
            {
                this.WindowState = FormWindowState.Maximized;
                check = true;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                check = false;
            }

        }

        private void btnWrap_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        Form frmSpravka = new Form();
        private void btnSpravka_Click(object sender, EventArgs e)
        {

            frmSpravka.Text = "Справочная информация";
            frmSpravka.Size = new Size(400, 400);
            frmSpravka.BackColor = Color.PeachPuff;
            frmSpravka.ControlBox = false;



            System.Windows.Forms.Button btnSpravkaClose = new System.Windows.Forms.Button();
            btnSpravkaClose.Text = "X";
            btnSpravkaClose.Size = new System.Drawing.Size(30, 30);
            btnSpravkaClose.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnSpravkaClose.BackColor = Color.AliceBlue;
            btnSpravkaClose.Location = new Point(340, 325);
            btnSpravkaClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSpravkaClose.Click += (s, ev) =>
            {
                frmSpravka.Close();
            };

            System.Windows.Forms.Button btnSpravkaWrap = new System.Windows.Forms.Button();
            btnSpravkaWrap.Text = "-";
            btnSpravkaWrap.Size = new System.Drawing.Size(30, 30);
            btnSpravkaWrap.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnSpravkaWrap.BackColor = Color.AliceBlue;
            btnSpravkaWrap.Location = new Point(310, 325);
            btnSpravkaWrap.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSpravkaWrap.Click += (s, ev) =>
            {
                frmSpravka.WindowState = FormWindowState.Minimized;
            };

            System.Windows.Forms.Button btnSpravkaTurn = new System.Windows.Forms.Button();
            btnSpravkaTurn.Text = "";
            btnSpravkaTurn.Size = new System.Drawing.Size(30, 30);
            btnSpravkaTurn.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnSpravkaTurn.BackColor = Color.AliceBlue;
            btnSpravkaTurn.Location = new Point(280, 325);
            btnSpravkaTurn.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSpravkaTurn.Click += (s, ev) =>
            {
                if (frmSpravka.WindowState == FormWindowState.Maximized)
                {
                    frmSpravka.WindowState = FormWindowState.Normal;
                    btnSpravkaTurn.Text = "";
                }
                else
                {
                    frmSpravka.WindowState = FormWindowState.Maximized;
                    btnSpravkaTurn.Text = "";
                }
            };

            frmSpravka.Controls.Add(btnSpravkaTurn);
            frmSpravka.Controls.Add(btnSpravkaClose);
            frmSpravka.Controls.Add(btnSpravkaWrap);

            System.Windows.Forms.Label lblSpravka = new System.Windows.Forms.Label();
            lblSpravka.AutoSize = false;
            lblSpravka.Size = new Size(frmSpravka.ClientRectangle.Width, frmSpravka.ClientRectangle.Height - 40);
            lblSpravka.Location = new Point(0, 10);
            lblSpravka.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblSpravka.Text = File.ReadAllText("spravka.txt");

            frmSpravka.SizeChanged += (s, ev) =>
            {
                lblSpravka.Size = new Size(frmSpravka.ClientRectangle.Width, frmSpravka.ClientRectangle.Height - 40);
            };

            frmSpravka.Controls.Add(lblSpravka);
            frmSpravka.ShowDialog();
        }
        Form frmProgram = new Form();
        private void btnStart_Click(object sender, EventArgs e)
        {

            frmProgram.Text = "Задание №3 выполнили: Поваляева А.В., Топталова С.Д.; Номер варианта: 2; Дата выполнения: 20/05/2024";
            frmProgram.Size = new Size(800, 500);
            frmProgram.BackColor = Color.PeachPuff;
            frmProgram.ControlBox = false;


            System.Windows.Forms.Button btnProgramClose = new System.Windows.Forms.Button();
            btnProgramClose.Text = "X";
            btnProgramClose.Size = new System.Drawing.Size(30, 30);
            btnProgramClose.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnProgramClose.BackColor = Color.AliceBlue;
            btnProgramClose.Location = new Point(750, 420);
            btnProgramClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnProgramClose.Click += (s, ev) =>
            {
                frmProgram.Close();
            };

            System.Windows.Forms.Button btnProgramWrap = new System.Windows.Forms.Button();
            btnProgramWrap.Text = "-";
            btnProgramWrap.Size = new System.Drawing.Size(30, 30);
            btnProgramWrap.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnProgramWrap.BackColor = Color.AliceBlue;
            btnProgramWrap.Location = new Point(720, 420);
            btnProgramWrap.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnProgramWrap.Click += (s, ev) =>
            {
                frmProgram.WindowState = FormWindowState.Minimized;
            };

            System.Windows.Forms.Button btnProgramTurn = new System.Windows.Forms.Button();
            btnProgramTurn.Text = "";
            btnProgramTurn.Size = new System.Drawing.Size(30, 30);
            btnProgramTurn.Font = new Font("Times New Roman", 14, FontStyle.Bold);
            btnProgramTurn.BackColor = Color.AliceBlue;
            btnProgramTurn.Location = new Point(690, 420);
            btnProgramTurn.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnProgramTurn.Click += (s, ev) =>
            {
                if (frmProgram.WindowState == FormWindowState.Maximized)
                {
                    frmProgram.WindowState = FormWindowState.Normal;
                    btnProgramTurn.Text = "";
                }
                else
                {
                    frmProgram.WindowState = FormWindowState.Maximized;
                    btnProgramTurn.Text = "";
                }
            };

            System.Windows.Forms.ComboBox cbFunc = new System.Windows.Forms.ComboBox();
            cbFunc.Location = new Point(40, 40);
            cbFunc.Size = new System.Drawing.Size(200, 150);
            cbFunc.Items.Add("Выражение (x*x-x+7)/(x+7)");
            cbFunc.Items.Add("Косинус");
            cbFunc.Items.Add("Возведение в квадрат");
            cbFunc.Items.Add("Арктангенс");
            cbFunc.Items.Add("Извлечение корня");
            cbFunc.Items.Add("Арксинус");
            cbFunc.Items.Add("Тангенс");
            cbFunc.Items.Add("Десятичный логарифм");
            cbFunc.Items.Add("Синус");
            cbFunc.Items.Add("Арккосинус");
            cbFunc.Items.Add("Логарифм по основанию 2");
            cbFunc.Items.Add("Натуральный логарифм");
            cbFunc.SelectedIndex = 0;

            System.Windows.Forms.ListBox lBZnach = new System.Windows.Forms.ListBox();
            lBZnach.Location = new Point(40, 100);
            lBZnach.Size = new Size(250, 300);
            frmProgram.Controls.Add(lBZnach);

            System.Windows.Forms.ListBox lBRezult = new System.Windows.Forms.ListBox();
            lBRezult.Location = new Point(400, 100);
            lBRezult.Size = new Size(250, 300);
            frmProgram.Controls.Add(lBRezult);

            System.Windows.Forms.TextBox tBStart = new System.Windows.Forms.TextBox();
            System.Windows.Forms.TextBox tBEnd = new System.Windows.Forms.TextBox();
            System.Windows.Forms.TextBox tBStep = new System.Windows.Forms.TextBox();

            tBStart.Location = new Point(280, 40);
            tBStart.Size = new System.Drawing.Size(50, 100);

            tBEnd.Location = new Point(350, 40);
            tBEnd.Size = new System.Drawing.Size(50, 100);

            tBStep.Location = new Point(420, 40);
            tBStep.Size = new System.Drawing.Size(50, 100);

            System.Windows.Forms.Button btnSchet = new System.Windows.Forms.Button();

            btnSchet.Size = new System.Drawing.Size(150, 40);
            btnSchet.Font = new Font("Times New Roman", 12, FontStyle.Bold);
            btnSchet.BackColor = Color.AliceBlue;
            btnSchet.Text = "Рассчитать";
            btnSchet.Location = new Point(40, 400);
            btnSchet.AutoSize = false;
            frmProgram.Controls.Add(btnSchet);

            btnSchet.Click += (s, ev) =>
            {
                lBZnach.Items.Clear();
                lBRezult.Items.Clear();


                if (string.IsNullOrEmpty(tBStart.Text) || string.IsNullOrEmpty(tBEnd.Text) || string.IsNullOrEmpty(tBStep.Text))
                {
                    MessageBox.Show("Введите все параметры");
                    return;
                }


                if (!int.TryParse(tBStart.Text, out int start) || !int.TryParse(tBEnd.Text, out int end) || !int.TryParse(tBStep.Text, out int step))
                {
                    MessageBox.Show("Введены некорректные значения параметров.");
                    return;
                }

                string selectedFormula = cbFunc.SelectedItem.ToString();


                for (int x = start; x <= end; x += step)
                {
                    lBZnach.Items.Add(x);

                    double result = 0;


                    switch (selectedFormula)
                    {
                        case "Выражение (x*x-x+7)/(x+7)":
                            result = (x * x - x + 7) / (x + 7);
                            break; 
                        case "Косинус":
                            result = Math.Cos(x);
                            break; 
                        case "Возведение в квадрат":
                            result = Math.Pow(x, 2);
                            break;
                        case "Арктангенс":
                            result = Math.Atan(x);
                            break; 
                        case "Извлечение корня":
                            result = Math.Sqrt(x);
                            break; 
                        case "Арксинус":
                            result = Math.Asin(x);
                            break; 
                        case "Тангенс":
                            result = Math.Tan(x);
                            break; 
                        case "Десятичный логарифм":
                            result = Math.Log10(x);
                            break;   
                        case "Синус":
                            result = Math.Sin(x);
                            break;
                        case "Арккосинус":
                            result = Math.Acos(x);
                            break;
                        case "Логарифм по основанию 2":
                            result = Math.Log(x, 2);
                            break;
                       
                        case "Натуральный логарифм":
                            result = Math.Log(x);
                            break;
                      
                        default:
                            result = 0; // Если формула не определена, результат будет 0
                            break;
                    }

                    lBRezult.Items.Add(result);

                }
                string filePath = "data.txt";


                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    for (int i = 0; i < lBZnach.Items.Count; i++)
                    {
                        string argument = lBZnach.Items[i].ToString();
                        string result = lBRezult.Items[i].ToString();
                        writer.WriteLine($"{argument} % {result}");
                    }
                }


               
            };

            lBZnach.SelectedIndexChanged += (s, ev) =>
            {
                lBRezult.SelectedIndex = lBZnach.SelectedIndex;
            };

            lBRezult.SelectedIndexChanged += (s, ev) =>
            {
                lBZnach.SelectedIndex = lBRezult.SelectedIndex;
            };

            System.Windows.Forms.Button btnLoadData = new System.Windows.Forms.Button();
            btnLoadData.Text = "Округлить";
            btnLoadData.Size = new System.Drawing.Size(150, 40);
            btnLoadData.Font = new Font("Times New Roman", 12, FontStyle.Bold);
            btnLoadData.BackColor = Color.AliceBlue; ;
            btnLoadData.Location = new Point(200, 400);
            btnLoadData.AutoSize = false;
            frmProgram.Controls.Add(btnLoadData);
            btnLoadData.Click += (s, ev) =>
            {
                lBZnach.Items.Clear();
                lBRezult.Items.Clear();

                string filePath = "data.txt";
                string[] lines = File.ReadAllLines(filePath);

                int Rounding = (2 % 5) + 1;

                foreach (string line in lines)
                {
                    string[] parts = line.Split(new[] { "%" }, StringSplitOptions.None);
                    if (parts.Length == 2)
                    {
                        string argument = parts[0];
                        double result = double.Parse(parts[1]);

                        result = Math.Round(result, Rounding);

                        lBZnach.Items.Add(argument);
                        lBRezult.Items.Add(result);
                    }
                }

            };
            frmProgram.Controls.Add(btnProgramTurn);
            frmProgram.Controls.Add(btnProgramClose);
            frmProgram.Controls.Add(btnProgramWrap);
            frmProgram.Controls.Add(cbFunc);
            frmProgram.Controls.Add(lBZnach);
            frmProgram.Controls.Add(lBRezult);
            frmProgram.Controls.Add(tBStart);
            frmProgram.Controls.Add(tBEnd);
            frmProgram.Controls.Add(tBStep);


            frmProgram.ShowDialog();

        }

    }

}

