﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace WinForms4
{
    public partial class frmMain : Form
    {
        private MonthCalendar mcTrigger, mcHolidays;
        private Label lblHelp, lblHoliday;
        private ComboBox cmbDates;
        List<string> HolidayNames = new List<string>();
        List<DateTime> HolidayDates = new List<DateTime>();
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Задание №4 выполнил: Поваляева А.В., Топталова С.Д.; Номер варианта: 2; Дата выполнения: 27.05.2024";
            this.mcTrigger = new MonthCalendar();
            this.mcTrigger.Location = new Point(18, 18);
            this.mcHolidays = new MonthCalendar();
            this.mcHolidays.Location = new Point(200, 18);
            this.lblHelp = new Label();
            this.lblHelp.Location = new Point(400, 18);
            this.lblHelp.Size = new Size(400, 200);
            this.lblHoliday = new Label();
            this.lblHoliday.Location = new Point(18, 200);
            this.lblHoliday.Size = new Size(180, 50);
            this.cmbDates = new ComboBox();
            this.cmbDates.Location = new Point(200, 200);
            this.cmbDates.Size = new Size(165, 50);
            this.cmbDates.SelectedIndexChanged += CmbDates_SelectedIndexChanged;
            this.Controls.Add(this.mcTrigger);
            this.Controls.Add(this.mcHolidays);
            this.Controls.Add(this.lblHelp);
            this.Controls.Add(this.lblHoliday);
            this.Controls.Add(this.cmbDates);
            this.KeyDown += Form1_KeyDown;
            this.mcTrigger.KeyDown += Form1_KeyDown;
            this.mcHolidays.KeyDown += Form1_KeyDown;
            this.cmbDates.KeyDown += Form1_KeyDown;
            this.mcTrigger.MouseDown += mcTrigger_MouseDown;
            StreamReader sr = new StreamReader(Application.StartupPath + "\\Holidays.txt");
            string[] temp = sr.ReadLine().Split(',');
            foreach (string date in temp)
            {
                this.HolidayDates.Add(Convert.ToDateTime(date));
            }
            this.HolidayDates.Sort();
            foreach (DateTime date in this.HolidayDates) 
            {
                this.cmbDates.Items.Add(date.ToString("d"));
            }
            this.HolidayNames.AddRange(sr.ReadLine().Split(','));
            sr.Close();
        }

        private void CmbDates_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.mcHolidays.SelectionStart = this.HolidayDates[this.cmbDates.SelectedIndex];
            this.mcHolidays.SelectionEnd = this.HolidayDates[this.cmbDates.SelectedIndex];
        }

        private void mcTrigger_MouseDown(object sender, MouseEventArgs e)
        {
            Random rnd = new Random();
            int index = rnd.Next(1, this.HolidayDates.Count);
            this.lblHoliday.Text = this.HolidayNames[index];
            this.mcHolidays.AddBoldedDate(this.HolidayDates[index]);
            this.mcHolidays.UpdateBoldedDates();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.H)
            {
                StreamReader sr = new StreamReader(Application.StartupPath + "\\Help.txt");
                string info = sr.ReadToEnd();
                sr.Close();
                this.lblHelp.Text = info;
            }
        }
    }
}
